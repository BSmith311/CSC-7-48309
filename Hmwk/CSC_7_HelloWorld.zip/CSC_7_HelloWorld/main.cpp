/* 
 * File:   main.cpp
 * Author: Brandon Smith
 * Created on August 24, 2022
 * Purpose: Hello World Program
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map inputs to outputs -> The Process
    
    //Display Results
    cout<<"Hello World"<<endl;
    //Exit stage right
        return 0;
}

